#import <UIKit/UIKit.h>

@interface StructuredGeocoderViewController : UIViewController

@end
