#import <UIKit/UIKit.h>

@interface PanoramaViewController : UIViewController

@end
