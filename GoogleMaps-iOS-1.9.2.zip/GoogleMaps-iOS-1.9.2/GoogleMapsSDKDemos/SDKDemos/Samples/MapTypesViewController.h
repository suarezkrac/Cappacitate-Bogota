#import <UIKit/UIKit.h>

@interface MapTypesViewController : UIViewController

@end
