#import <UIKit/UIKit.h>

@interface VisibleRegionViewController : UIViewController

@end
